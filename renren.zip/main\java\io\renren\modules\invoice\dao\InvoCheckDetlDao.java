package io.renren.modules.invoice.dao;

import io.renren.modules.invoice.entity.InvoCheckDetlEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * 
 * 
 * @author sunzh
 * @email kjustsun@gmail.com
 * @date 2018-08-04 16:54:52
 */
public interface InvoCheckDetlDao extends BaseMapper<InvoCheckDetlEntity> {
	
}
